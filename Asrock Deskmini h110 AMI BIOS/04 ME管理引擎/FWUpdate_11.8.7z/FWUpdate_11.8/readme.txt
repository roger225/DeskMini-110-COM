Intel (R) Firmware Update Utility Version: 11.8.50.3434
Copyright (C) 2007 - 2017, Intel Corporation.  All rights reserved.

FWUpdLcl.exe [-H|?] [-VER] [-EXP] [-VERBOSE] [-F] [-Y] [-SAVE]
             [-FWVER] [-PARTID] [-ALLOWSV] [-FORCERESET] [-OEMID] [-PASS]
             [-GENERIC] [-PARTVER]

-H|?                    Displays help screen.
-VER                    Displays version information.
-EXP                    Displays example usage of this tool.
-VERBOSE<file>          Display the debug information of the tool.
-F <file>               File used for updating the FW.
-Y                      Automatically answer Yes to prompts.
-SAVE <file>            Save the current FW to an update image.
-FWVER<file>            Display the FW Version of current FW or update image.
-PARTID<Partition ID>   Provide specific Partition ID to perform partial update.
-ALLOWSV                Allows same version firmware updates.
-FORCERESET             Automatically Reboots system after update (if needed).
-OEMID <UUID>           OEM ID needed to perform firmware update.
-PASS <pass>            MeBX password. Optional with the '-f' option.
-GENERIC                Perform the update through MEI without credentials.
-PARTVER <Partition ID> Display the Version of specific partition.

